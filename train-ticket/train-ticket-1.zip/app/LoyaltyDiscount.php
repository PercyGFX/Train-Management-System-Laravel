<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoyaltyDiscount extends Model
{
    //
}
