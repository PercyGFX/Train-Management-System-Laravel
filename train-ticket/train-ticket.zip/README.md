Laravel application

TO RUN:
1. composer install 

2. php artisan serve