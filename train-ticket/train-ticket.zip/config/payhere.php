<?php

return [
    'sandbox' => true, // Set this to true for the sandbox environment
    'merchant_id' => '1223617',
    'secret_key' => 'MzM5NjI0OTc0NzQyMDg3MjIwMzExMzY0Nzg0MTEzOTA3NDA5MDE0',
    // You can add other configuration options here, if needed
];